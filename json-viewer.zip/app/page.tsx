import JsonViewer from "../json-viewer"

export default function Page() {
  return <JsonViewer />
}
